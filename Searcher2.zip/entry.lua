self_ID = "Searcher2"
declare_plugin(self_ID,
{
image     	 = "FC3.bmp",
installed 	 = true, -- if false that will be place holder , or advertising
dirName	  	 = current_mod_path,
displayName  = _("Searcher2"),
developerName = _("Searcher2"),

fileMenuName = _("Searcher2"),
update_id        = "Searcher2",
version		 = "2.1.1",
state		 = "installed",
info		 = _("БПЛА Форпост (Searcher2). семейство израильских тактических разведывательных беспилотных летательных аппаратов, разработанных концерном IAI. Основной задачей БПЛА является ведение воздушной разведки, в том числе в зоне боевых действий; также может использоваться для целеуказания, наведения и корректировки огня артиллерии."),

encyclopedia_path 	= current_mod_path..'/Encyclopedia',

Skins	=
	{
		{
		    name	= _("Форпост"),
			dir		= "Theme"
		},
	},	
	

Missions =
	{
		{
			name	= _("Форпост"),
			dir		= "Missions",
  		},
	},	
	

})
----------------------------------------------------------------------------------------
mount_vfs_model_path	(current_mod_path.."/Shapes")
mount_vfs_liveries_path (current_mod_path.."/Liveries")
mount_vfs_texture_path  (current_mod_path.."/Textures/Searcher2")
mount_vfs_sound_path	(current_mod_path.."/Sounds")
-------------------------------------------------------------------------------------
--Форпост
-------------------------------------------------------------------------------------
dofile(current_mod_path.."/Views.lua")
dofile(current_mod_path..'/Searcher2.lua')
-------------------------------------------------------------------------------------
plugin_done()
