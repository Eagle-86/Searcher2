
Searcher2 =  {
      
		Name 			= 'Searcher2',--AG
		DisplayName		= _('Форпост'),--AG
        Picture 		= "Searcher2.png",
        Rate 			= "40",
        Shape			= "Searcher2",--AG	
        WorldID			=  WSTYPE_PLACEHOLDER, 
		singleInFlight 	= true,
        
	shape_table_data 	= 
	{
		{
			file  	 	= 'Searcher2';--AG
			life  	 	= 18; -- lifebar
			vis   	 	= 3; -- visibility gain.
			desrt    	= 'self'; -- Name of destroyed object file name
			fire  	 	= { 300, 2}; 			-- Fire on the ground after destoyed: 300sec 2m
			username	= 'Searcher2';--AG
			index       =  WSTYPE_PLACEHOLDER;
			classname   = "lLandPlane";
			positioning = "BYNORMAL";
			drawonmap 	= true;
		},
	},
	
    mapclasskey 		= "P0091000023",
 	attribute  			= {wsType_Air, wsType_Airplane, wsType_Fighter, WSTYPE_PLACEHOLDER ,"Battleplanes","UAVs"},
		
	    Categories = {
        },
				
	M_empty 					= 2223 , -- kg
	M_nominal 					= 4273, -- kg
	M_max 						= 4760, -- kg
	M_fuel_max 					= 1300, -- kg --2225
	H_max 					 	= 7010, -- m
	average_fuel_consumption 	= 0.302, -- this is highly relative, but good estimates are 36-40l/min = 28-31kg/min = 0.47-0.52kg/s -- 45l/min = 35kg/min = 0.583kg/s
	CAS_min 					= 100/3.6, -- if this is not OVERAL FLIGHT TIME, but jus LOITER TIME, than it sholud be 10-15 minutes.....CAS capability in minute (for AI)
	V_opt 						= 44,-- Cruise speed (for AI)
	V_take_off 					= 100/3.6, -- Take off speed in m/s (for AI)
	V_land 						= 100/3.6, -- Land speed in m/s (for AI)
	V_max_sea_level 			= 250/3.6, -- Max speed at sea level in m/s (for AI)
	V_max_h 					= 250/3.6, -- Max speed at max altitude in m/s (for AI)
	Vy_max 						= 5, -- Max climb speed in m/s (for AI)
	Mach_max 					= 0.25, -- Max speed in Mach (for AI)
	Ny_min 						= -1, -- Min G (for AI)
	Ny_max 						= 3,  -- Max G (for AI)
	Ny_max_e 					= 2,  -- Max G (for AI)
	AOA_take_off 				= 3/57.3, -- AoA in take off (for AI)
	bank_angle_max 				= 30, -- Max bank angle (for AI) максимальный угол крена


	has_afteburner 				= false, -- AFB yes/no
	has_speedbrake 				= false, -- Speedbrake yes/no
	has_differential_stabilizer	= false, -- differential stabilizers
	
	--nose_gear_pos 				= {2.504 , -0.850,	0}, -- nosegear coord
	--main_gear_pos 				= {-0.628, -0.850,  1.888}, -- main gear coords
	
	
	nose_gear_pos 				= {2.504 , -0.820,	0}, -- nosegear coord
--	main_gear_pos 				= {-0.2, -0.750,  1.888}, -- main gear coords
	main_gear_pos 				= {-0.2, -0.750,  0.5}, -- main gear coords
	
	nose_gear_amortizer_direct_stroke    	 =  0,  -- down from nose_gear_pos !!!
	nose_gear_amortizer_reversal_stroke  	 = -0.196,  -- up 

	main_gear_amortizer_direct_stroke		 =  0, --  down from main_gear_pos !!!
	main_gear_amortizer_reversal_stroke  	 = 	0, --  up 
	nose_gear_amortizer_normal_weight_stroke = -0.075,
	
    tand_gear_max 				= 0.577, -- возможно поворот
	tanker_type 				= 0, -- Tanker type if the plane is airrefuel capable
	wing_area 					= 23.52, -- wing area in m2
	wing_span 					= 20, -- wing spain in m
	wing_type 					= 0,
	thrust_sum_max 				= 8224, -- thrust in kg (44kN)
	thrust_sum_ab 				= 8224, -- thrust inkg (71kN)
	length 						= 5.85, -- full lenght in m
	height 						= 8.55, -- height in m
	flaps_maneuver 				= 0.5, -- Max flaps in take-off and maneuver (0.5 = 1st stage; 1.0 = 2nd stage) (for AI)
	range 						= 5920, -- Max range in km (for AI)
	RCS 						= 0.5, -- Radar Cross Section m2
	IR_emission_coeff 			= 0.1, -- Normal engine -- IR_emission_coeff = 1 is Su-27 without afterburner. It is reference.
	IR_emission_coeff_ab 		= 0, -- With afterburner
	wing_tip_pos 				= {-1.1,	0,	10}, -- wingtip coords for visual effects
	nose_gear_wheel_diameter 	= 0.174, -- in m
	main_gear_wheel_diameter 	= 0.23, -- in m
	brakeshute_name 			= 0, -- Landing - brake chute visual shape after separation
	is_tanker 					= false, -- Tanker yes/no
	air_refuel_receptacle_pos 	= {0, 0, 0}, -- refuel coords
	engines_count				= 1, -- Engines count
	engines_nozzles = {
		[1] = 
		{
			pos 		=  {1.97,-0.09,-0.56}, -- nozzle coords
			elevation   =  0, -- AFB cone elevation
			diameter	 = 0*0.1, -- AFB cone diameter
			exhaust_length_ab   = -3.0, -- lenght in m
			exhaust_length_ab_K = 0.3, -- AB animation
			engine_number  = 1, --both to first engine
		}, -- end of [1]
	}, -- end of engines_nozzles
	
	
	
		crew_members =  --UAV
	{
	}, -- end of crew_members

	fires_pos = 
	{
		[1] = 	{1,	0.5,0},
		[2] = 	{0.6 ,-0.25,	0.95},
		[3] = 	{-0.1,-0.3 ,	0.95},
		[4] = 	{2,	-0.5,	0.4},
		[5] = 	{-0.4,	-0.25,	-2},
		[6] = 	{-1.9,	-0.18,	0.4},
		[7] = 	{-1.9,	-0.18, -0.4},
		[8] = 	{1.7,	-0.1,	0.55},
		[9] = 	{1.7,	-0.1,  -0.55},
		[10] = 	{-5,	0.5,	0},
		[11] = 	{-5,	0.5,	0},
	}, -- end of fires_pos	

    singleInFlight = true,
	
 	detection_range_max		 = 0,
	radar_can_see_ground 	 = true, -- this should be examined (what is this exactly?)
	CanopyGeometry = makeAirplaneCanopyGeometry(LOOK_BAD, LOOK_BAD, LOOK_BAD),
    Sensors = {
            OPTIC = {"RQ-1 Predator CAM", "RQ-1 Predator FLIR"},
            RADAR =  "RQ-1 Predator SAR"
    },

	
		brakeshute_name	=	0,
		is_tanker	=	false,


	Failures = {
					{ id = 'asc', 			label = _('ASC'), 			enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
					{ id = 'autopilot', label = _('AUTOPILOT'), enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
					{ id = 'hydro',  		label = _('HYDRO'), 		enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
					{ id = 'l_engine',  label = _('L-ENGINE'), 	enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
					{ id = 'r_engine',	label = _('R-ENGINE'), 	enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
	},
	HumanRadio = {
		frequency = 127.5,  -- Radio Freq
		editable = true,
		minFrequency = 100.000,
		maxFrequency = 156.000,
		modulation = MODULATION_AM
	},

	Pylons =     {

        pylon(1, 0, 0, 0, 0,
            {
            },
            {
            }
        ),
	},
	
	EPLRS = true,
	Tasks = {
		aircraft_task(GroundAttack),
        aircraft_task(CAS),
        aircraft_task(AFAC),
		aircraft_task(Reconnaissance),
    },	
	DefaultTask = aircraft_task(Reconnaissance),

	
		SFM_Data =
	{
		aerodynamics = -- Cx = Cx_0 + Cy^2*B2 +Cy^4*B4
		{
			Cy0			=	0.3,
			Mzalfa		=	6.6,
			Mzalfadt	=	1,
			kjx	=	2.85,
			kjz	=	0.00125,
			Czbe	=	-0.012,
			cx_gear	=	0.002,
			cx_flap	=	0.01,
			cy_flap	=	0.3,
			cx_brk	=	0.025,
			table_data = 
			{--  M		Cx0		Cya		B		B4	   Omxmax	Aldop		Cymax
				{0	,	0.026,	0.12,	0.0227,	0.0001,	1,		20,	1.4},
				{0.4,	0.026,	0.12,	0.0227,	0.0001,	1,		20,	1.4},
				{1	,	0.026,	0.12,	0.0227,	0.0001,	1,		20,	1.4},
			}, -- end of table_data
		}, -- end of aerodynamics
	
	
		engine = 
		{
			Nmg		=	20.5, -- RPM at idle
			MinRUD	=	0, -- Min state of the throttle
			MaxRUD	=	1, -- Max state of the throttle
			MaksRUD	=	1, -- Military power state of the throttle
			ForsRUD	=	1, -- Afterburner state of the throttle
			typeng	=	3,--  E_TURBOPROP	
			hMaxEng	=	17, -- Max altitude for safe engine operation in km
			dcx_eng	=	0.015, -- Engine drag coeficient
			cemax	=	0.37, -- not used for fuel calulation , only for AI routines to check flight time ( fuel calculation algorithm is built in )
			cefor	=	0.37, -- not used for fuel calulation , only for AI routines to check flight time ( fuel calculation algorithm is built in )
			dpdh_m	=	1800, --  altitude coefficient for max thrust
			dpdh_f	=	1800,  --  altitude coefficient for AB thrust
			
			k_adiab_1			= 0.037923,
			k_adiab_2			= 0.0562,
			MAX_Manifold_P_1	= 180000,		
			MAX_Manifold_P_2	= 180000,		
			MAX_Manifold_P_3	= 180000,		
			k_after_cool		= 0.0,
			Displ				= 35,
			k_Eps				= 6.5,
			Stroke				= 0.165,
			V_pist_0			= 13,
			Nu_0				= 1.2,
			Nu_1				= 0.9,
			Nu_2				= 0.001,
			N_indic_0			= 1052480,
			N_fr_0				= 0.04,
			N_fr_1				= 0.001,
			Init_Mom			= 220,
			D_prop				= 3.5,
			MOI_prop			= 45,
			k_gearbox			= 2.4,
			P_oil				= 495438,
			k_boost				= 3,
			k_cfug				= 0.003,
			k_oil				= 0.00004,
			k_piston			= 3000,
			k_reg				= 0.003,
			k_vel				= 0.017,
			table_data = 
			{
			--   M			Pmax
				{0.0,		16620.0},
				{0.1,		15600.0},
				{0.2,		14340.0},
				{0.3,		13320.0},
				{0.4,		12230.0},
				{0.5,		11300.0},
				{0.6,		10600.0},
				{0.7,		10050.0},
				{0.8,		 9820.0},
				{0.9,		 5902.0},
				{1.9,		 3469.0}
			}
			-- M - Mach number
			-- Pmax - Engine thrust at military power
			-- Pfor - Engine thrust at AFB
		}, -- end of engine
	},


	--damage , index meaning see in  Scripts\Aircrafts\_Common\Damage.lua
	Damage = {
	[0]  = {critical_damage = 5,  args = {146}},
	[1]  = {critical_damage = 3,  args = {296}},
	[2]  = {critical_damage = 3,  args = {297}},
	[3]  = {critical_damage = 8, args = {65}},
	[4]  = {critical_damage = 2,  args = {298}},
	[5]  = {critical_damage = 2,  args = {301}},
	[7]  = {critical_damage = 2,  args = {249}},
	[8]  = {critical_damage = 3,  args = {265}},
	[9]  = {critical_damage = 3,  args = {154}},
	[10] = {critical_damage = 3,  args = {153}},
	[11] = {critical_damage = 1,  args = {167}},
	[12] = {critical_damage = 1,  args = {161}},
	[13] = {critical_damage = 2,  args = {169}},
	[14] = {critical_damage = 2,  args = {163}},
	[15] = {critical_damage = 2,  args = {267}},
	[16] = {critical_damage = 2,  args = {266}},
	[17] = {critical_damage = 2,  args = {168}},
	[18] = {critical_damage = 2,  args = {162}},
	[20] = {critical_damage = 2,  args = {183}},
	[23] = {critical_damage = 5, args = {223}},--wing out left 
	[24] = {critical_damage = 5, args = {213}},--wing out right 
	[25] = {critical_damage = 2,  args = {226}},--eleron left 
	[26] = {critical_damage = 2,  args = {216}},--eleron right 
	[29] = {critical_damage = 5, args = {224}, deps_cells = {23, 25}},
	[30] = {critical_damage = 5, args = {214}, deps_cells = {24, 26}},
	[35] = {critical_damage = 6, args = {225}, deps_cells = {23, 29, 25, 37}},--wing in left 
	[36] = {critical_damage = 6, args = {215}, deps_cells = {24, 30, 26, 38}},--wing in right 
	[37] = {critical_damage = 2,  args = {228}},
	[38] = {critical_damage = 2,  args = {218}},
	[39] = {critical_damage = 2,  args = {244}, deps_cells = {53}}, 
	[40] = {critical_damage = 2,  args = {241}, deps_cells = {54}}, 
	[43] = {critical_damage = 2,  args = {243}, deps_cells = {39, 53}},
	[44] = {critical_damage = 2,  args = {242}, deps_cells = {40, 54}}, 
	[51] = {critical_damage = 2,  args = {240}},--elevator in left
	[52] = {critical_damage = 2,  args = {237}},--elevator in right
	[53] = {critical_damage = 2,  args = {248}},--rudder left
	[54] = {critical_damage = 2,  args = {247}},
	[56] = {critical_damage = 2,  args = {158}},
	[57] = {critical_damage = 2,  args = {157}},
	[59] = {critical_damage = 3,  args = {148}},
	[61] = {critical_damage = 2,  args = {147}},
	[82] = {critical_damage = 2,  args = {152}},
	},
	
	DamageParts = 
	{  
		[1] = "Searcher2-OBLOMOK-WING-R", -- wing R
		[2] = "Searcher2-OBLOMOK-WING-L", -- wing L
	},
	
-- VSN DCS World\Scripts\Aircrafts\_Common\Lights.lua

	lights_data = {	typename = "collection", lights = {
    [1] = {typename = "collection",lights = {}},
	[2] = {typename = "collection",
			lights = {-- Landing light
			        	{typename = "natostrobelight", connector = "TOP_BEACON",    argument_1 = 83,  period = 1.333, color = {0.99, 0.11, 0.3}, phase_shift = 0.0},

    					{-- Landing/Taxi light
					   typename = "spotlight",
					   connector = "MAIN_SPOT_PTR_01",
					   argument = 208,
					   dir_correction = {elevation = math.rad(3)}
					  }
					 }
			},
    [3]	= {typename = "collection",
			lights = {-- Left Position Light (red)
					  --RED
 			         {typename = "omnilight",
					   connector = "BANO_1",
					   color = {0.99, 0.11, 0.3},
					   pos_correction  = {0, 0, -0.2},
					   argument  = 190
					  },
  					  -- Right Position Light (green)
					  {typename = "omnilight",
					   connector = "BANO_2",
					   color = {0, 0.894, 0.6},
					   pos_correction = {0, 0, 0.2},
					   argument  = 191
					  },
			          --WHITE
					   {typename = "omnilight",
					   connector = "BANO_0",
				       color = {1.0, 1.0, 1.0},
					   pos_correction  = {0, 0, -0.2},
					   argument  = 192
					   },
					   -- RED
					   {typename = "omnilight",
					   connector = "BANO_4",
					   color = {0.99, 0.11, 0.3},
					   pos_correction  = {0, 0, 0},
					   argument  = 193
					   },	
					   --GREEN
					   {typename = "omnilight",
					   connector = "BANO_3",
					   color = {0, 0.894, 0.6},
					   pos_correction  = {0, 0, 0},
					   argument  = 194
					   }
					   }
			},
    [4] = {typename = "collection",lights = {}},
	[5]	= {typename = "collection",lights = {}},
	}},
	
		ViewSettings = ViewSettings,
	Countries = {"Russia","Syria", "Israil", "China","India","Spain"},
}

add_aircraft(Searcher2)
