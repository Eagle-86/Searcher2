lessons = 
{
	{
        ["file"] = "Forpost_Single_Caucasus.miz",
        ["name"] = _("Форпост Кавказ"),
        ["description"] = _("Работа по лазерному подсвету"),
    },
	
	{
        ["file"] = "Forpost_Single_Nevada.miz",
        ["name"] = _("Форпост Невада"),
        ["description"] = _("Работа по лазерному подсвету"),
    },
} -- end of lessons
