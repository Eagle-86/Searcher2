planes = {
     {
    name = _('Форпост Кавказ'),
    file = 'Forpost_Single_Caucasus.miz',
    },
	
     {
    name = _('Форпост Невада'),
    file = 'Forpost_Single_Nevada.miz',
    },
		
}