livery = {
 	{"Searcher2_Korpus", 0, "Searcher2_korpus.tga",false},
 	{"Searcher2_Korpus_Small", 0, "Searcher2_Korpus_Small.tga",false},
 	{"Searcher2_wingL", 0, "Searcher2_wingL.tga",false},
 	{"Searcher2_wingR", 0, "Searcher2_wingR.tga",false},
 	{"Searcher2_wingS", 0, "Searcher2_wingS.tga",false},
 	{"Searcher2_truba", 0, "Searcher2_truba.tga",false},
}
name = "2 Standart Blue"
name_ru = "`Стандартная Синяя`"
countries = {"USA", "RUS", "FRA", "UKR", "SPN", "NETH", "TUR", "BEL", "GER", "NOR", "CAN", "DEN", "UK", "GRG", "ISR", "ABH", "RSO", "ITA", "INS", "AUS","HUN","IND","IRN","IRQ","JPN","KAZ","PRK","PAK","POL","ROU","SAU","SRB","SVK","KOR","SWE","SYR","YEM","VNM","VEN","TUN","THA","SDN","PHL","MAR","MEX","MYS","LBY","JOR","IDN","HND","ETH","CHL","BRA","BHR","NZG","YUG","SUN","RSI","BLR","CHN","CZE","HRV","EGY","FIN","GRC","BGR","AUSAF","AUT","SUI"}
