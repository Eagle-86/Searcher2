livery = {

}
name = "1 Standart"
name_ru = "`Стандартная Серая`"
countries = {"RUS",}